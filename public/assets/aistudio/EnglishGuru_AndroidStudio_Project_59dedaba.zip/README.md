# English Guru — Android Studio Project

## જરૂરી સોફ્ટવેર
- Android Studio (recent stable version)
- Android SDK 35
- Internet connection for the first Gradle sync only

## ચલાવવાની રીત
1. ZIP ફાઇલ Extract કરો.
2. Android Studio ખોલો અને `Open` પસંદ કરો.
3. Extract કરેલી `EnglishGuru` ફોલ્ડર પસંદ કરો.
4. Gradle Sync પૂર્ણ થવા દો.
5. Android ફોનમાં USB debugging ચાલુ કરીને ફોન જોડો અથવા Emulator શરૂ કરો.
6. Run (▶) દબાવો.

## એપમાં સામેલ
- ગુજરાતી હોમ સ્ક્રીન
- 5 શરૂઆતના પાઠ
- શબ્દભંડોળ અને Text-to-Speech ઉચ્ચાર
- MCQ ક્વિઝ અને સ્કોર
- SharedPreferences દ્વારા સ્થાનિક પ્રગતિ સાચવવી

## નોંધ
આ Starter MVP છે. તેમાં હાલ 5 પાઠ, મર્યાદિત શબ્દો અને 4 ક્વિઝ પ્રશ્નો છે. Play Store પર પ્રકાશિત કરતાં પહેલાં વધુ પાઠ/શબ્દો, સંપૂર્ણ Gujarati TTS ઉપલબ્ધતા, accessibility, વિવિધ Android ઉપકરણો પર પરીક્ષણ, privacy policy અને release signing ઉમેરવા/ચકાસવા જરૂરી છે. આ ZIP source project છે; APK નથી.
