package com.englishguru.app

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

data class Lesson(val title: String, val subtitle: String, val examples: List<Pair<String,String>>)
data class Word(val english: String, val gujarati: String, val pronunciation: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EnglishGuruApp() }
    }
}

private val lessons = listOf(
    Lesson("અંગ્રેજી અક્ષરો", "ABC થી શરૂઆત", listOf(
        "A" to "એ", "B" to "બી", "C" to "સી", "D" to "ડી",
        "E" to "ઈ", "F" to "એફ", "G" to "જી", "H" to "એચ"
    )),
    Lesson("અભિવાદન", "મળતી વખતે બોલાતા શબ્દો", listOf(
        "Hello" to "નમસ્તે", "Good morning" to "સુપ્રભાત",
        "Good evening" to "શુભ સાંજ", "Good night" to "શુભ રાત્રિ",
        "Thank you" to "આભાર", "Sorry" to "માફ કરશો"
    )),
    Lesson("મારું પરિચય", "પોતાના વિશે બોલતા શીખો", listOf(
        "My name is Ravi." to "મારું નામ રવિ છે.",
        "I am from Gujarat." to "હું ગુજરાતથી છું.",
        "I am a student." to "હું વિદ્યાર્થી છું.",
        "I am learning English." to "હું અંગ્રેજી શીખી રહ્યો છું."
    )),
    Lesson("રોજિંદા વાક્યો", "દરરોજ ઉપયોગી વાક્યો", listOf(
        "How are you?" to "તમે કેમ છો?",
        "I am fine." to "હું મજામાં છું.",
        "What is your name?" to "તમારું નામ શું છે?",
        "Please help me." to "કૃપા કરીને મારી મદદ કરો.",
        "I don't understand." to "મને સમજાતું નથી."
    )),
    Lesson("સરળ Grammar", "વાક્ય બનાવવાની શરૂઆત", listOf(
        "I am happy." to "હું ખુશ છું.",
        "You are good." to "તમે સારા છો.",
        "He is a teacher." to "તે શિક્ષક છે.",
        "She is my friend." to "તે મારી મિત્ર છે."
    ))
)

private val words = listOf(
    Word("Water","પાણી","વોટર"), Word("Food","ખોરાક","ફૂડ"),
    Word("House","ઘર","હાઉસ"), Word("Book","પુસ્તક","બુક"),
    Word("School","શાળા","સ્કૂલ"), Word("Friend","મિત્ર","ફ્રેન્ડ"),
    Word("Beautiful","સુંદર","બ્યુટીફુલ"), Word("Today","આજે","ટુડે"),
    Word("Tomorrow","આવતીકાલે","ટુમોરો"), Word("Thank you","આભાર","થેન્ક યુ")
)

private data class Question(val question: String, val options: List<String>, val answer: String, val meaning: String)
private val questions = listOf(
    Question("'પાણી' નો અંગ્રેજી શબ્દ કયો?", listOf("Food","Water","Book","House"), "Water", "પાણી = Water"),
    Question("'આભાર' માટે કયો શબ્દ વપરાય?", listOf("Sorry","Hello","Thank you","Good night"), "Thank you", "આભાર = Thank you"),
    Question("'ઘર' નો અંગ્રેજી શબ્દ કયો?", listOf("School","House","Friend","Today"), "House", "ઘર = House"),
    Question("'તમે કેમ છો?' નું અંગ્રેજી શું?", listOf("How are you?","Who are you?","Good night","I am fine"), "How are you?", "તમે કેમ છો? = How are you?")
)

@Composable
fun EnglishGuruApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("english_guru", 0) }
    var selectedTab by remember { mutableStateOf("Home") }
    var completed by remember { mutableIntStateOf(prefs.getInt("completed", 0)) }
    var bestScore by remember { mutableIntStateOf(prefs.getInt("best", 0)) }
    var selectedLesson by remember { mutableStateOf<Lesson?>(null) }
    var quizStarted by remember { mutableStateOf(false) }

    val tts = remember {
        TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // English voice is selected when Speak is pressed.
            }
        }
    }
    DisposableEffect(Unit) { onDispose { tts.stop(); tts.shutdown() } }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF2457C5),
            secondary = androidx.compose.ui.graphics.Color(0xFF00A884),
            background = androidx.compose.ui.graphics.Color(0xFFF5F7FB)
        )
    ) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    val tabs = listOf(
                        Triple("Home", "હોમ", Icons.Default.Home),
                        Triple("Lessons", "પાઠ", Icons.Default.MenuBook),
                        Triple("Words", "શબ્દો", Icons.Default.Translate),
                        Triple("Quiz", "ક્વિઝ", Icons.Default.Quiz),
                        Triple("Progress", "પ્રગતિ", Icons.Default.BarChart)
                    )
                    tabs.forEach { (key, label, icon) ->
                        NavigationBarItem(
                            selected = selectedTab == key,
                            onClick = { selectedTab = key; selectedLesson = null; quizStarted = false },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (selectedLesson != null) {
                    LessonDetail(
                        lesson = selectedLesson!!,
                        onBack = { selectedLesson = null },
                        onSpeak = { speak(tts, it) },
                        onComplete = {
                            completed++
                            prefs.edit().putInt("completed", completed).apply()
                            selectedLesson = null
                        }
                    )
                } else when (selectedTab) {
                    "Home" -> HomeScreen(completed, bestScore, onLessons = { selectedTab = "Lessons" }, onQuiz = { selectedTab = "Quiz" })
                    "Lessons" -> LessonsScreen { selectedLesson = it }
                    "Words" -> WordsScreen(onSpeak = { speak(tts, it) })
                    "Quiz" -> QuizScreen(
                        started = quizStarted,
                        onStart = { quizStarted = true },
                        onFinish = { score ->
                            if (score > bestScore) {
                                bestScore = score
                                prefs.edit().putInt("best", bestScore).apply()
                            }
                        }
                    )
                    else -> ProgressScreen(completed, bestScore)
                }
            }
        }
    }
}

private fun speak(tts: TextToSpeech, text: String) {
    tts.language = Locale.US
    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "english_guru")
}

@Composable
fun Header(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(20.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun HomeScreen(completed: Int, best: Int, onLessons: () -> Unit, onQuiz: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(22.dp)) {
                    Text("નમસ્તે! 👋", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleLarge)
                    Text("ચાલો, આજે અંગ્રેજી શીખીએ.", color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onLessons, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Text("શીખવાનું શરૂ કરો", color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        item { Text("તમારી પ્રગતિ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("પૂર્ણ પાઠ", completed.toString(), Modifier.weight(1f))
                StatCard("શ્રેષ્ઠ સ્કોર", "$best%", Modifier.weight(1f))
            }
        }
        item { Text("આજનો શબ્દ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item {
            Card {
                Column(Modifier.padding(18.dp)) {
                    Text("Good morning", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                    Text("સુપ્રભાત")
                    Text("ઉચ્ચાર: ગુડ મોર્નિંગ", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { Button(onClick = onQuiz, modifier = Modifier.fillMaxWidth()) { Text("નાની ક્વિઝ આપો") } }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun LessonsScreen(onOpen: (Lesson) -> Unit) {
    Column {
        Header("શીખવાના પાઠ", "શરૂઆતથી ધીમે ધીમે અંગ્રેજી શીખો")
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(lessons) { lesson ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(lesson) }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MenuBook, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(lesson.title, fontWeight = FontWeight.Bold)
                            Text(lesson.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }
        }
    }
}

@Composable
fun LessonDetail(lesson: Lesson, onBack: () -> Unit, onSpeak: (String) -> Unit, onComplete: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "પાછા") }
            Text(lesson.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(lesson.examples) { pair ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(pair.first, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            Text(pair.second)
                        }
                        IconButton(onClick = { onSpeak(pair.first) }) { Icon(Icons.Default.VolumeUp, "ઉચ્ચાર સાંભળો") }
                    }
                }
            }
        }
        Button(onClick = onComplete, modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text("પાઠ પૂર્ણ કર્યો") }
    }
}

@Composable
fun WordsScreen(onSpeak: (String) -> Unit) {
    Column {
        Header("શબ્દભંડોળ", "નવા અંગ્રેજી શબ્દો શીખો")
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(words) { word ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(word.english, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(word.gujarati)
                            if (word.pronunciation.isNotBlank()) Text("ઉચ્ચાર: ${word.pronunciation}", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { onSpeak(word.english) }) { Icon(Icons.Default.VolumeUp, "સાંભળો") }
                    }
                }
            }
        }
    }
}

@Composable
fun QuizScreen(started: Boolean, onStart: () -> Unit, onFinish: (Int) -> Unit) {
    var index by remember(started) { mutableIntStateOf(0) }
    var score by remember(started) { mutableIntStateOf(0) }
    var chosen by remember(started) { mutableStateOf<String?>(null) }
    var finished by remember(started) { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Header("અંગ્રેજી ક્વિઝ", "તમારી સમજ ચકાસો")
        if (!started) {
            Text("આ ટેસ્ટમાં ${questions.size} પ્રશ્નો છે. દરેક પ્રશ્નનો સાચો જવાબ પસંદ કરો.")
            Spacer(Modifier.height(20.dp))
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("ટેસ્ટ શરૂ કરો") }
        } else if (finished) {
            Text("તમારો ટેસ્ટ પૂર્ણ થયો! 🎉", style = MaterialTheme.typography.headlineSmall)
            Text("તમારો સ્કોર: $score / ${questions.size} (${score * 100 / questions.size}%)")
            Spacer(Modifier.height(16.dp))
            Button(onClick = { onFinish(score * 100 / questions.size) }) { Text("સ્કોર સાચવો") }
        } else {
            val q = questions[index]
            LinearProgressIndicator(progress = { (index + 1f) / questions.size }, modifier = Modifier.fillMaxWidth())
            Text("પ્રશ્ન ${index + 1} / ${questions.size}", modifier = Modifier.padding(vertical = 12.dp))
            Text(q.question, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            q.options.forEach { option ->
                OutlinedButton(
                    onClick = { if (chosen == null) { chosen = option; if (option == q.answer) score++ } },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (chosen == option) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface
                    )
                ) { Text(option) }
                Spacer(Modifier.height(6.dp))
            }
            if (chosen != null) {
                Text(if (chosen == q.answer) "સાચો જવાબ! ✓" else "સાચો જવાબ: ${q.answer}")
                Text(q.meaning, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    if (index == questions.lastIndex) finished = true
                    else { index++; chosen = null }
                }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (index == questions.lastIndex) "પરિણામ જુઓ" else "આગળનો પ્રશ્ન")
                }
            }
        }
    }
}

@Composable
fun ProgressScreen(completed: Int, best: Int) {
    Column(Modifier.fillMaxSize()) {
        Header("તમારી પ્રગતિ", "તમારી શીખવાની સફર")
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("પૂર્ણ કરેલા પાઠ", style = MaterialTheme.typography.titleMedium)
                Text("$completed / ${lessons.size}", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(
                    progress = { (completed.toFloat() / lessons.size).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                )
                Text("શ્રેષ્ઠ ક્વિઝ સ્કોર: $best%")
                Text("દરરોજ થોડો સમય પ્રેક્ટિસ કરતા રહો!")
            }
        }
    }
}
